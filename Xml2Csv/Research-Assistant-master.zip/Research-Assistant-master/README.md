# xmls from aws server to csv

Converts all the xml files in the input directory to csv files in the output directory.
The files which couldn't be converted are printed on the console.

First we need to install xmltodict package which will convert xml to a dictionary.

```python
conda install -c conda-forge xmltodict
```
After that run the src file and get the results.
